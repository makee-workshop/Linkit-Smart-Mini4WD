//
//  main.m
//  mini4wdUsingGPchip
//
//  Created by ArcherHuang on 2015/12/13.
//  Copyright © 2015年 Makee.io All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
